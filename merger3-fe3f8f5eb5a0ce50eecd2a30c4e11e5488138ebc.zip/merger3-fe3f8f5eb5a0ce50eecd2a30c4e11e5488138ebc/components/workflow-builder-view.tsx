'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { GitMerge, Plus, Search, Settings, ArrowRight, Activity, ShieldAlert, Cpu, Mail, MessageSquare, Zap, Terminal } from 'lucide-react';

export function WorkflowBuilderView() {
  return (
    <div className="space-y-8 font-sans text-slate-900 bg-white min-h-[calc(100vh-8rem)] p-8 rounded-3xl shadow-sm border border-slate-200">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-200 pb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="font-serif text-4xl font-medium tracking-tight text-slate-900">
              Workflow Builder
            </h1>
            <span className="flex items-center gap-1.5 px-3 py-1 bg-teal-50 text-teal-700 text-xs font-bold uppercase tracking-widest rounded-full border border-teal-200">
              <GitMerge size={14} /> Dependency Mapping
            </span>
          </div>
          <p className="text-slate-500 max-w-2xl text-base leading-relaxed">
            Visually map automated workflows and dependencies. Configure Apphia Engine rules for signal routing and automated actions.
          </p>
        </div>
        <div className="flex gap-3">
          <button className="inline-flex items-center gap-2 bg-white border border-slate-200 text-slate-700 px-4 py-2 rounded-md hover:bg-slate-50 transition-colors font-medium shadow-sm">
            <Settings size={16} /> Configure
          </button>
          <button className="inline-flex items-center gap-2 bg-navy-900 text-white px-4 py-2 rounded-md hover:bg-navy-800 transition-colors font-medium shadow-sm bg-slate-900 hover:bg-slate-800">
            <Plus size={16} /> New Node
          </button>
        </div>
      </header>

      <div className="relative h-[600px] border border-slate-200 rounded-2xl bg-slate-50 overflow-hidden flex flex-col">
        {/* Toolbar */}
        <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm flex items-center px-3 py-1.5">
            <Search size={16} className="text-slate-400 mr-2" />
            <input 
              type="text" 
              placeholder="Search nodes..." 
              className="bg-transparent border-none outline-none text-sm w-48 text-slate-700 placeholder:text-slate-400"
            />
          </div>
          <div className="bg-white border border-slate-200 rounded-lg shadow-sm flex items-center px-3 py-1.5 gap-4 text-sm font-medium text-slate-600">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-teal-500"></div>
              <span>Critical Path</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <span>Blocked</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-slate-300"></div>
              <span>Pending</span>
            </div>
          </div>
        </div>

        {/* Canvas Area (Mocked for MVP) */}
        <div className="flex-1 relative w-full h-full flex items-center justify-center">
          {/* Background Grid */}
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
          
          {/* Mock Nodes & Connections */}
          <div className="relative w-full max-w-4xl h-96">
            
            {/* SVG Lines for connections */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
              <path d="M 150 150 C 250 150, 250 100, 350 100" fill="none" stroke="#0d9488" strokeWidth="3" strokeDasharray="5,5" className="animate-pulse" />
              <path d="M 150 150 C 250 150, 250 250, 350 250" fill="none" stroke="#cbd5e1" strokeWidth="2" />
              <path d="M 550 100 C 650 100, 650 100, 750 100" fill="none" stroke="#ef4444" strokeWidth="3" />
              <path d="M 550 250 C 650 250, 650 250, 750 250" fill="none" stroke="#0d9488" strokeWidth="2" />
            </svg>

            {/* Nodes */}
            <div className="absolute top-[110px] left-[20px] w-48 bg-white border-2 border-slate-300 rounded-xl p-4 shadow-sm z-10">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Trigger</div>
              <div className="font-semibold text-slate-900 text-sm">New Email Received</div>
              <div className="text-xs text-slate-500 mt-2 flex items-center gap-1"><Mail size={12}/> Inbox</div>
            </div>

            <div className="absolute top-[60px] left-[350px] w-56 bg-white border-2 border-teal-500 rounded-xl p-4 shadow-lg z-10 ring-4 ring-teal-500/10">
              <div className="flex justify-between items-start mb-1">
                <div className="text-xs font-bold uppercase tracking-wider text-teal-600">Condition</div>
                <span className="bg-teal-100 text-teal-700 text-[10px] px-2 py-0.5 rounded-full font-bold">ACTIVE</span>
              </div>
              <div className="font-semibold text-slate-900 text-sm">If Sentiment == Negative</div>
              <div className="text-xs text-slate-500 mt-2 flex items-center gap-1"><Cpu size={12}/> Apphia Engine</div>
            </div>

            <div className="absolute top-[210px] left-[350px] w-56 bg-white border border-slate-300 rounded-xl p-4 shadow-sm z-10">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Condition</div>
              <div className="font-semibold text-slate-900 text-sm">If Sentiment == Positive</div>
              <div className="text-xs text-slate-500 mt-2 flex items-center gap-1"><Cpu size={12}/> Apphia Engine</div>
            </div>

            <div className="absolute top-[60px] left-[750px] w-48 bg-red-50 border-2 border-red-400 rounded-xl p-4 shadow-md z-10">
              <div className="flex justify-between items-start mb-1">
                <div className="text-xs font-bold uppercase tracking-wider text-red-600">Action</div>
                <ShieldAlert size={14} className="text-red-500" />
              </div>
              <div className="font-semibold text-slate-900 text-sm">Escalate to PMO</div>
              <div className="text-xs text-red-500 mt-2 font-medium">High Priority Alert</div>
            </div>

            <div className="absolute top-[210px] left-[750px] w-48 bg-teal-50 border-2 border-teal-400 rounded-xl p-4 shadow-md z-10">
              <div className="flex justify-between items-start mb-1">
                <div className="text-xs font-bold uppercase tracking-wider text-teal-600">Action</div>
                <MessageSquare size={14} className="text-teal-600" />
              </div>
              <div className="font-semibold text-slate-900 text-sm">Draft Response</div>
              <div className="text-xs text-teal-600 mt-2 font-medium">Auto-generate reply</div>
            </div>

          </div>
        </div>

        {/* Bottom Panel */}
        <div className="bg-white border-t border-slate-200 p-4 flex flex-col md:flex-row justify-between items-center gap-4 z-10">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-slate-600">
              <Cpu size={16} className="text-teal-600" />
              <span className="font-medium text-slate-900">Apphia Analysis:</span> 
              1 bottleneck detected in Phase 3.
            </div>
            <button className="text-sm font-medium text-teal-600 hover:text-teal-700 underline underline-offset-2">
              View Recommendation
            </button>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">Last synced: Just now</span>
            <div className="h-4 w-px bg-slate-200 mx-2" />
            <div className="flex items-center gap-1 text-emerald-600 text-[10px] font-bold uppercase tracking-widest">
              <Activity size={12} />
              Real-time Sync Active
            </div>
          </div>
        </div>
      </div>

      {/* AI Suggestions Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 text-white p-8 rounded-3xl shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:opacity-20 transition-opacity">
            <Zap size={120} />
          </div>
          <div className="relative z-10 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-teal-500 flex items-center justify-center">
                <Cpu size={20} />
              </div>
              <div>
                <h3 className="text-xl font-serif font-medium">Diagnostic-Based Suggestions</h3>
                <p className="text-teal-400 text-xs font-mono uppercase tracking-widest">Apphia</p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { title: 'Automated Triage', desc: 'Based on high email volume, we suggest adding a sentiment analysis node before PMO escalation.', icon: Mail },
                { title: 'Resource Reallocation', desc: 'Tech-Ops latency is high. Auto-scale infrastructure nodes during peak hours (9AM-11AM).', icon: Terminal },
              ].map((suggestion, i) => (
                <div key={i} className="bg-white/5 border border-white/10 p-5 rounded-2xl hover:bg-white/10 transition-all cursor-pointer">
                  <div className="flex items-center gap-3 mb-3">
                    <suggestion.icon size={16} className="text-teal-400" />
                    <h4 className="font-medium text-sm">{suggestion.title}</h4>
                  </div>
                  <p className="text-xs text-white/60 leading-relaxed mb-4">{suggestion.desc}</p>
                  <button className="text-[10px] font-bold uppercase tracking-widest text-teal-400 flex items-center gap-2 hover:gap-3 transition-all">
                    Implement Now <ArrowRight size={12} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 space-y-6">
          <h3 className="text-lg font-serif font-medium">System Health</h3>
          <div className="space-y-4">
            {[
              { label: 'Automation Efficiency', value: 84, color: 'bg-emerald-500' },
              { label: 'Node Latency', value: 12, color: 'bg-teal-500' },
              { label: 'Error Rate', value: 2, color: 'bg-rose-500' },
            ].map((stat, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-xs font-medium">
                  <span className="text-slate-500">{stat.label}</span>
                  <span className="text-slate-900">{stat.value}%</span>
                </div>
                <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${stat.value}%` }}
                    className={`h-full ${stat.color}`}
                  />
                </div>
              </div>
            ))}
          </div>
          <div className="pt-6 border-t border-slate-100">
            <button className="w-full py-3 bg-slate-100 text-slate-600 rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-slate-200 transition-all">
              Run Full Diagnostic
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
